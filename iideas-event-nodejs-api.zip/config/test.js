const nodemailer = require('nodemailer');

// Create transporter
const transporter = nodemailer.createTransport({
    host: 'Mail.cssoffice.sg',
    port: 587,
    secure: false,              // Set to true if port is 465
    auth: {
        user: 'Dev@cssoffice.sg',
        pass: 'CSSdemo@0736',
    },
    tls: {
        rejectUnauthorized: false,
    },
});

// Verify connection (optional but useful)
transporter.verify((error, success) => {
    if (error) {
        console.log('SMTP Connection Error:', error);
    } else {
        console.log('SMTP Server is ready to send emails');
    }
});

// Send test email
const mailOptions = {
    from: '"Test Mail" <dev@cssoffice.sg>',
    to: 'prasantasarentangent@gmail.com',
    subject: 'SMTP Test Email',
    text: 'This is a test email using Nodemailer',
    html: '<b>This is a test email using Nodemailer</b>'
};

transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
        console.log('Error while sending mail:', error);
    } else {
        console.log('Email sent successfully:', info.response);
    }
});