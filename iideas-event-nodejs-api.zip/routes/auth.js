const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const db = require('../config/db'); 
const { sendOtpToAttendee } = require('../emailService/index');

/**
 * @swagger
 * /api/auth/login:
 *   post:
 *     tags:
 *       - Auth
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               username:
 *                 type: string
 *               password:
 *                 type: string
 *     responses:
 *       200:
 *         description: Token returned
 */

router.post('/login', async (req, res) => {
  let conn;
  try {
    conn = await db.getConnection();
    const requestJson = JSON.stringify(req.body); // JSON input as string
    const [rows] = await conn.execute(
      "CALL USP_POST_USER_AUTHENTICATE_ACTIVITY(?, ?, @ERRNO, @ERRMSG);",
      ['AUTHENTICATE_USER', requestJson]
    );
    if (rows && rows[0] && rows[0][0]) {
      const result = rows[0][0].JSON_VALUE;
      if (result.status === 'true') {
        const userData = {
          UserId: result.USER_ID,
          UserSysId: result.USER_SYS_ID,
          FirstName: result.FIRST_NAME,
          BranchSysId: result.BRANCH_SYS_ID,
          Organisation_Sys_Id: result.ORGANISATION_SYS_ID,
          Role: result.SYSTEM_ROLE_NAME,
        };
        const token = jwt.sign(userData, process.env.JWT_SECRET, { expiresIn: '7d' });
        return res.json({ Token: token, ...result });
      } 
      else {
        return res.status(401).json(result);
      }
    } else {
      return res.status(500).json({ status: 'false', response: 'Oops!! something went wrong' });
    }
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
  finally {
    if (conn) conn.release();
  }
});

/**
 * @swagger
 * /api/auth/api-post-authenticate-module-credentials:
 *   post:
 *     tags:
 *       - Auth
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               EVENT_CODE:
 *                 type: string
 *               EVENT_MODULE_SYS_ID:
 *                 type: string
 *               PASSWORD:
 *                 type: string
 *     responses:
 *       200:
 *         description: Token returned
 */

router.post('/api-post-authenticate-module-credentials', async (req, res) => {
  let conn;
  try {
    conn = await db.getConnection();
    const requestJson = JSON.stringify(req.body); // JSON input as string
    const [rows] = await conn.execute(
      "CALL USP_POST_MODULE_CREDENTIALS_AUTH_ACTIVITY(?, ?, @ERRNO, @ERRMSG);",
      ['AUTH_MODULE_CREDENTIALS', requestJson]
    );
    if (rows && rows[0] && rows[0][0]) {
      const result = rows[0][0].JSON_VALUE;
      if (result.status === 'true') {
        const eventData = {
          event_name: result.EVENT_NAME,
          event_type: result.EVENT_TYPE,
          event_venue: result.EVENT_VENUE,
          event_status: result.EVENT_STATUS,
          event_sys_id: result.EVENT_SYS_ID,
          event_country: result.EVENT_COUNTRY,
          event_category: result.EVENT_CATEGORY,
          event_end_date: result.EVENT_END_DATE,
          event_endtime: result.EVENT_END_TIME,
          event_postcode: result.EVENT_POSTCODE,
          event_start_date: result.EVENT_START_DATE,
          event_start_time: result.EVENT_START_TIME,
          event_primary_adress: result.EVENT_PRIMARY_ADDRESS,
          event_secondary_address: result.EVENT_SECONDARY_ADDRESS,
        };
        const token = jwt.sign(eventData, process.env.JWT_SECRET, { expiresIn: '60m' });
        return res.json({ Token: token, ...result });
      } else {
        return res.status(401).json(result);
      }
    } else {
      return res.status(500).json({ status: 'false', response: 'Oops!! something went wrong' });
    }
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
    finally {
    if (conn) conn.release();
  }
});

// POST /api/auth/api-post-attendees-otp-verification
/**
 * @swagger
 * /api/auth/api-post-attendees-otp-verification:
 *   post:
 *     tags:
 *       - Auth
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: array
 *             items:
 *               type: object
 *     responses:
 *       200:
 *         description: Success Response
 */
router.post('/api-post-attendees-otp-verification', async (req, res) => {
  let conn;
  try {
    conn = await db.getConnection();
    const requestObj = req.body; // keep as object
    const requestJson = JSON.stringify(req.body); // Convert request body to JSON string
    const [rows] = await conn.execute(
      "CALL USP_POST_ATTENDEES_OTP_VERIFICATION_ACTIVITY(?, ?, @ERRNO, @ERRMSG);",
      ['OTP_VERIFICATION', requestJson]
    );
    if (rows && rows[0] && rows[0][0]) {
      const result = rows[0][0].JSON_VALUE;
      const token = jwt.sign(result, process.env.JWT_SECRET, { expiresIn: '120m' });
      return res.json({ Token: token, ...result });
    } else {
      return res.status(500).json({ status: 'false', response: 'Oops!! something went wrong' });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// POST /api/auth/api-post-attendees-qr-code-verification
/**
 * @swagger
 * /api/auth/api-post-attendees-qr-code-verification:
 *   post:
 *     tags:
 *       - Auth
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: array
 *             items:
 *               type: object
 *     responses:
 *       200:
 *         description: Success Response
 */
router.post('/api-post-attendees-qr-code-verification', async (req, res) => {
  let conn;
  try {
    conn = await db.getConnection();
    const requestObj = req.body; // keep as object
    const requestJson = JSON.stringify(req.body); // Convert request body to JSON string
    const [rows] = await conn.execute(
      "CALL USP_POST_ATTENDEES_QR_VERIFICATION_ACTIVITY(?, ?, @ERRNO, @ERRMSG);",
      ['QR_VERIFICATION', requestJson]
    );
    if (rows && rows[0] && rows[0][0]) {
      const result = rows[0][0].JSON_VALUE;
      if (result.status === 'true' && requestObj.ITEM === 'VERIFICATION_QR') {
        const token = jwt.sign(result, process.env.JWT_SECRET, { expiresIn: '120m' });
        return res.json({ Token: token, ...result });
      }
      // else if (result.status === 'true' && requestObj.ITEM === 'VERIFICATION_QR') {
      //   return res.status(200).json(result);
      // }
      else {
        return res.status(500).json(result);
      }
    } else {
      return res.status(500).json({ status: 'false', response: 'Oops!! something went wrong' });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
    finally {
    if (conn) conn.release();
  }
});


/**
 * @swagger
 * /api/auth/api-post-authenticate-client-user:
 *   post:
 *     tags:
 *       - Auth
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               username:
 *                 type: string
 *               password:
 *                 type: string
 *     responses:
 *       200:
 *         description: Token returned
 */

router.post('/api-post-authenticate-client-user', async (req, res) => {
  let conn;
  try {
    conn = await db.getConnection();
    const requestJson = JSON.stringify(req.body); // JSON input as string
    const [rows] = await conn.execute(
      "CALL USP_POST_CLIENT_USER_AUTHENTICATE_ACTIVITY(?, ?, @ERRNO, @ERRMSG);",
      ['CLIENT_AUTH_MODULE_CREDENTIALS', requestJson]
    );
    if (rows && rows[0] && rows[0][0]) {
      const result = rows[0][0].JSON_VALUE;
      if (result.status === 'true') {
        const userData = {
          eventSysId: result.EVENT_SYS_ID,
          UserName: result.USER_NAME,
          PersonName: result.PERSON_NAME,
          clientUserSysId: result.CLIENT_USER_SYS_ID,
        };
        const token = jwt.sign(userData, process.env.JWT_SECRET, { expiresIn: '1d' });
        return res.json({ Token: token, ...result });
      } 
      else {
        return res.status(401).json(result);
      }
    } else {
      return res.status(500).json({ status: 'false', response: 'Oops!! something went wrong' });
    }
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
  finally {
    if (conn) conn.release();
  }
});

// POST /api/auth/api-post-attendees-direct-login
/**
 * @swagger
 * /api/auth/api-post-attendees-direct-login:
 *   post:
 *     tags:
 *       - Auth
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: array
 *             items:
 *               type: object
 *     responses:
 *       200:
 *         description: Success Response
 */
router.post('/api-post-attendees-direct-login', async (req, res) => {
  let conn;
  try {
    conn = await db.getConnection();
    const requestObj = req.body; // keep as object
    const requestJson = JSON.stringify(req.body); // Convert request body to JSON string
    const [rows] = await conn.execute(
      "CALL USP_POST_ATTENDEES_DIRECT_LOGIN_ACTIVITY(?, ?, @ERRNO, @ERRMSG);",
      ['ATTENDEES_LOGIN', requestJson]
    );
    if (rows && rows[0] && rows[0][0]) {
      const result = rows[0][0].JSON_VALUE;
      if (result.status === 'true') {
        const token = jwt.sign(result, process.env.JWT_SECRET, { expiresIn: '7d' });
        return res.json({ Token: token, ...result });
      }
      else {
        return res.status(500).json(result);
      }
    } else {
      return res.status(500).json({ status: 'false', response: 'Oops!! something went wrong' });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});
module.exports = router;
