const swaggerJsdoc = require('swagger-jsdoc');

const options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'iideas - nodejs-api',
      version: '1.0.0',
      description: 'WHERE IDEAS COME FRESH',
    },
    components: {
      securitySchemes: {
        bearerAuth: {
          type: 'http',
          scheme: 'bearer',
          bearerFormat: 'JWT'
        }
      }
    },
    security: [{ bearerAuth: [] }],
    servers: [{ url: 'http://localhost:3000' }]
  },
  apis: ['./routes/*.js']
};

module.exports = swaggerJsdoc(options);