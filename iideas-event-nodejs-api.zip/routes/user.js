const express = require('express');
const router = express.Router();
const db = require('../config/db');
const auth = require('../middlewares/auth');

// POST /api/user/api-post-add-update-user
/**
 * @swagger
 * /api/user/api-post-add-update-user:
 *   post:
 *     tags:
 *       - User
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: array
 *             items:
 *               type: object
 *     responses:
 *       200:
 *         description: Success Response
 */
router.post('/api-post-add-update-user', auth, async (req, res) => {
  let conn;
  try {
    conn = await db.getConnection();
    const requestJson = JSON.stringify(req.body); // Convert request body to JSON string
    const [rows] = await conn.execute(
      "CALL USP_POST_USER_PROFILE_ACTIVITY(?, ?, @ERRNO, @ERRMSG);",
      ['ADD_UPDATE_USER', requestJson]
    );
    if (rows && rows[0] && rows[0][0]) {
      const result = rows[0][0].JSON_VALUE;
      return res.json(result);
    } else {
      return res.status(500).json({ status: 'false', response: 'Oops!! something went wrong' });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
    finally {
    if (conn) conn.release();
  }
});

// GET /api/user/api-get-view-user-profile-info
/**
 * @swagger
 * /api/user/api-get-view-user-profile-info:
 *   get:
 *     tags:
 *       - User
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: ITEM
 *         schema:
 *           type: string
 *         required: false
 *         example: SPECIFIC
 *       - in: query
 *         name: USER_SYS_ID
 *         schema:
 *           type: string
 *         required: false
 *         example: 0
 *     responses:
 *       200:
 *         description: JSON response from stored procedure
 */
router.get('/api-get-view-user-profile-info', auth, async (req, res) => {
  let conn;
  try {
    conn = await db.getConnection();
    const { ITEM, USER_SYS_ID } = req.query;
    const [rows] = await conn.execute(
      "CALL USP_GET_USER_PROFILE_INFO_ACTIVITY(?, ?, ?, @ERRNO, @ERRMSG);",
      ['VIEW_USER_INFO', ITEM, USER_SYS_ID]
    );
    if (rows && rows[0] && rows[0][0]) {
      const result = rows[0][0].JSON_VALUE;
      return res.json(result);
    } else {
      return res.status(500).json({ status: 'false', response: 'Oops!! something went wrong'});
    }
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
    finally {
    if (conn) conn.release();
  }
});


// GET /api/user/api-get-view-user-info
/**
 * @swagger
 * /api/user/api-get-view-user-info:
 *   get:
 *     tags:
 *       - User
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: ITEM
 *         schema:
 *           type: string
 *         required: false
 *         example: VIEW_USER
 *       - in: query
 *         name: NAME
 *         schema:
 *           type: string
 *         required: false
 *         example: ANY
 *       - in: query
 *         name: USER_SYS_ID
 *         schema:
 *           type: string
 *         required: false
 *         example: 0
 *       - in: query
 *         name: ROLE_NAME
 *         schema:
 *           type: string
 *         required: false
 *         example: ADMIN
 *       - in: query
 *         name: CONTACT_NO
 *         schema:
 *           type: string
 *         required: false
 *         example: 12345678
 *       - in: query
 *         name: EMAIL
 *         schema:
 *           type: string
 *         required: false
 *         example: admin@gmail.cm
 *       - in: query
 *         name: ACCOUNT_STATUS
 *         schema:
 *           type: string
 *         required: false
 *         example: active
 *       - in: query
 *         name: USER_TYPE
 *         schema:
 *           type: string
 *         required: false
 *         example: Internal
 *       - in: query
 *         name: BRANCH_SYS_ID
 *         schema:
 *           type: string
 *         required: false
 *         example: 0
 *       - in: query
 *         name: ORGANISATION_SYS_ID
 *         schema:
 *           type: string
 *         required: false
 *         example: 0
 *       - in: query
 *         name: PAGE_SIZE
 *         schema:
 *           type: string
 *         required: false
 *         example: 100
 *       - in: query
 *         name: PAGE_NO
 *         schema:
 *           type: string
 *         required: false
 *         example: 1
 *     responses:
 *       200:
 *         description: JSON response from stored procedure
 */
router.get('/api-get-view-user-info', auth, async (req, res) => {
  let conn;
  try {
    conn = await db.getConnection();
    const { ITEM, NAME, USER_SYS_ID, ROLE_NAME, CONTACT_NO, EMAIL, ACCOUNT_STATUS, USER_TYPE, BRANCH_SYS_ID, ORGANISATION_SYS_ID, PAGE_SIZE, PAGE_NO } = req.query;

    const params = [
      'VIEW_USER',
      ITEM ?? null,
      NAME ?? null,
      USER_SYS_ID ?? null,
      ROLE_NAME ?? null,
      CONTACT_NO ?? null,
      EMAIL ?? null,
      ACCOUNT_STATUS ?? null,
      USER_TYPE ?? null,
      BRANCH_SYS_ID ?? null,
      ORGANISATION_SYS_ID ?? null,
      PAGE_SIZE ?? null,
      PAGE_NO ?? null
    ];

    const [rows] = await conn.execute(
      "CALL USP_GET_USER_PROFILE_ACTIVITY(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, @ERRNO, @ERRMSG);",
      params
    );
    if (rows && rows[0] && rows[0][0]) {
      const result = rows[0][0].JSON_VALUE;
      return res.json(result);
    } else {
      return res.status(500).json({ status: 'false', response: 'Oops!! something went wrong' });
    }
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
  finally {
    if (conn) conn.release();
  }
});



module.exports = router;