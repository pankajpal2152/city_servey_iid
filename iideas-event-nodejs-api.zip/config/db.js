// 'use strict';
// const mysql = require('mysql2');
// const pool = mysql.createPool({
//   host: '139.177.186.96',
//   user: 'de0cssdemo_uat_iideas_user',
//   password: 'q*PCAV[n2O(bK=kL',
//   database: 'de0cssdemo_uat_iideas',
//   multipleStatements: true,
//   waitForConnections: true,    
//   connectionLimit: 10,          
//   queueLimit: 0,  
// });
// module.exports = pool.promise();

'use strict';
const mysql = require('mysql2');
const pool = mysql.createPool({
  host: 'tts-rds-dev-mysql.clcusias8hpu.ap-south-1.rds.amazonaws.com',
  user: 'tanmysqlrd',
  password: '0eTZ{Wo34g1&^96CSH1mZ=HWFMbQMx',
  database: 'DEV_IIDEAS_EVENT',
  multipleStatements: true,
  waitForConnections: true,    
  connectionLimit: 10,          
  queueLimit: 0,  
});
module.exports = pool.promise();