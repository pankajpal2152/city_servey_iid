const jwt = require('jsonwebtoken');

module.exports = function (req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  console.log('🔐 Received Token:', token);

  if (!token) {
    console.log('⛔ No token provided');
    return res.sendStatus(401);
  }

  jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
    if (err) {
      console.log('⛔ Token invalid:', err.message);
      return res.sendStatus(403);
    }

    console.log('✅ Token valid, user:', user);
    req.user = user;
    next();
  });
};
