# Node.js + Express + MySQL + JWT + Swagger

## ✅ Features
- Login API
- JWT Authentication
- MySQL Stored Procedures
- Swagger Auto Documentation

## 🔧 Setup Instructions

1. **Install Dependencies**
```
npm install
```

2. **Setup MySQL**
Create a database and run the following procedures:

```
DELIMITER //
CREATE PROCEDURE GetUserProfile(IN username VARCHAR(50))
BEGIN
  SELECT username AS name, CONCAT(username, '@mail.com') AS email;
END //
CREATE PROCEDURE UpdateUserProfile(IN username VARCHAR(50), IN name VARCHAR(50), IN email VARCHAR(50))
BEGIN
  SELECT 'Updated' AS status;
END //
DELIMITER ;
```

3. **Run the Server**
```
npm start
```

4. **Access Swagger**
Visit: [http://localhost:3000/api-docs](http://localhost:3000/api-docs)

## 📦 Login Credentials
```
POST /api/auth/login
Body: { "username": "admin", "password": "admin" }
```