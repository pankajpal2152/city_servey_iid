const express = require("express");
const router = express.Router();
const { processStripePayment } = require("../config/payment/stripe");
const { createPayPalOrder, capturePayPalOrder } = require("../config/payment/paypal");
 
/**
 * POST /api/payment/stripe
 * Process a Stripe card payment using a Stripe.js token
 */
router.post("/stripe", async (req, res) => {
  try {
    const result = await processStripePayment(req.body);
    return res.status(200).json(result);
  } catch (err) {
    console.error("Stripe Route Error:", err.message);
    return res.status(err.statusCode || 500).json({
      success: false,
      error: err.message,
      code: err.code || null,
      decline_code: err.decline_code || null,
    });
  }
});

//paypal//
/**
 * POST /api/payment/paypal/create
 * Create a PayPal order and get the approve URL
 *MethodEndpointPurposePOST/api/payment/stripeCharge card via StripePOST/api/payment/paypal/createCreate PayPal order → get approve_urlPOST/api/payment/paypal/captureCapture after user approves
 
PayPal flow is 2 steps (unlike Stripe which is 1):

Call /create → redirect user to approve_url
After user approves on PayPal, call /capture with the order_id
 * Body: { amount, currency, reference_id }
 */
router.post("/paypal/create", async (req, res) => {
  try {
    const result = await createPayPalOrder(req.body);
    return res.status(200).json(result);
  } catch (err) {
    console.error("PayPal Create Error:", err.message);
    return res.status(err.statusCode || 500).json({
      success: false,
      error: err.message,
    });
  }
});
 
/**
 * POST /api/payment/paypal/capture
 * Capture payment after user approves on PayPal
 *
 * Body: { order_id }
 */
router.post("/paypal/capture", async (req, res) => {
  try {
    const { order_id } = req.body;
    const result = await capturePayPalOrder(order_id);
    return res.status(200).json(result);
  } catch (err) {
    console.error("PayPal Capture Error:", err.message);
    return res.status(err.statusCode || 500).json({
      success: false,
      error: err.message,
    });
  }
});
 
module.exports = router;